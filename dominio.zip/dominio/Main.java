
public class Main {
    public static void main(String[] args) {
        
        Animal rex = new Animal();
        rex.nome = "Rex";
        rex.idade = 10;
        
        rex.emitirSom();


    }

}
