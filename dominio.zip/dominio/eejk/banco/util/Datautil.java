package br.eejk.banco.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DataUtil {
    
    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter FORMATO_DATA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
    
    private DataUtil() {
        // Classe utilitária não deve ser instanciada
    }
    
    public static String formatarData(LocalDate data) {
        if (data == null) return "";
        return data.format(FORMATO_DATA);
    }
    
    public static String formatarDataHora(LocalDateTime dataHora) {
        if (dataHora == null) return "";
        return dataHora.format(FORMATO_DATA_HORA);
    }
    
    public static String dataHoje() {
        return LocalDate.now().format(FORMATO_DATA);
    }
    
    public static String dataHoraAgora() {
        return LocalDateTime.now().format(FORMATO_DATA_HORA);
    }
    
    public static LocalDate stringParaData(String dataString) {
        try {
            return LocalDate.parse(dataString, FORMATO_DATA);
        } catch (Exception e) {
            throw new IllegalArgumentException("Data inválida. Use o formato dd/MM/yyyy");
        }
    }
}