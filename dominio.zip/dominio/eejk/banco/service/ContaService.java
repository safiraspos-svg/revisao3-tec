package br.eejk.banco.service;

import br.eejk.banco.model.*;
import br.eejk.banco.repository.ContaRepository;

public class ContaService {
    
    private ContaRepository repository;
    
    public ContaService(ContaRepository repository) {
        this.repository = repository;
    }
    
    public void criarContaCorrente(int numero, Cliente titular, double limite) {
        if (repository.existeConta(numero)) {
            System.out.println("Erro: Conta " + numero + " já existe");
            return;
        }
        ContaCorrente cc = new ContaCorrente(numero, titular, limite);
        repository.salvar(cc);
        System.out.println("Conta corrente " + numero + " criada");
    }
    
    public void criarContaPoupanca(int numero, Cliente titular) {
        if (repository.existeConta(numero)) {
            System.out.println("Erro: Conta " + numero + " já existe");
            return;
        }
        ContaPoupanca cp = new ContaPoupanca(numero, titular);
        repository.salvar(cp);
        System.out.println("Conta poupança " + numero + " criada");
    }
    
    public boolean depositar(int numeroConta, double valor) {
        Conta conta = repository.buscarPorNumero(numeroConta);
        if (conta == null) {
            System.out.println("Erro: Conta " + numeroConta + " não encontrada");
            return false;
        }
        conta.depositar(valor);
        return true;
    }
    
    public boolean sacar(int numeroConta, double valor) {
        Conta conta = repository.buscarPorNumero(numeroConta);
        if (conta == null) {
            System.out.println("Erro: Conta " + numeroConta + " não encontrada");
            return false;
        }
        
        boolean sucesso = conta.sacar(valor);
        if (!sucesso) {
            System.out.println("Erro: Saldo insuficiente na conta " + numeroConta);
        }
        return sucesso;
    }
    
    public boolean transferir(int origem, int destino, double valor) {
        Conta contaOrigem = repository.buscarPorNumero(origem);
        Conta contaDestino = repository.buscarPorNumero(destino);
        
        if (contaOrigem == null || contaDestino == null) {
            System.out.println("Erro: Conta origem ou destino não encontrada");
            return false;
        }
        
        return contaOrigem.transferir(valor, contaDestino);
    }
    
    public void atualizarTodasContas() {
        for (Conta conta : repository.listarTodas()) {
            conta.atualizar();
        }
        System.out.println("Todas as contas foram atualizadas");
    }
    
    public void exibirDadosConta(int numero) {
        Conta conta = repository.buscarPorNumero(numero);
        if (conta != null) {
            conta.exibirDados();
        } else {
            System.out.println("Conta " + numero + " não encontrada");
        }
    }
    
    public void cobrarTaxas() {
        for (Conta conta : repository.listarTodas()) {
            if (conta instanceof Tributavel) {
                Tributavel t = (Tributavel) conta;
                double taxa = t.calcularTaxa();
                System.out.println("Cobrando R$" + taxa + " da conta " + conta.getNumero());
            }
        }
    }
}