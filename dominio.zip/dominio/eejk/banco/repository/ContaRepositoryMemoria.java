package br.eejk.banco.repository;

import br.eejk.banco.model.Conta;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContaRepositoryMemoria implements ContaRepository {
    
    private Map<Integer, Conta> contas = new HashMap<>();
    
    @Override
    public void salvar(Conta conta) {
        contas.put(conta.getNumero(), conta);
    }
    
    @Override
    public Conta buscarPorNumero(int numero) {
        return contas.get(numero);
    }
    
    @Override
    public List<Conta> listarTodas() {
        return new ArrayList<>(contas.values());
    }
    
    @Override
    public boolean remover(int numero) {
        if (contas.containsKey(numero)) {
            contas.remove(numero);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean existeConta(int numero) {
        return contas.containsKey(numero);
    }
}