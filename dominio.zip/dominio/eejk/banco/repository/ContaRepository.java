package br.eejk.banco.repository;

import br.eejk.banco.model.Conta;
import java.util.List;

public interface ContaRepository {
    
    void salvar(Conta conta);
    
    Conta buscarPorNumero(int numero);
    
    List<Conta> listarTodas();
    
    boolean remover(int numero);
    
    boolean existeConta(int numero);
    
}