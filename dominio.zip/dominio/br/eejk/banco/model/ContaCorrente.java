package br.eejk.banco.model;

public class ContaCorrente extends Conta implements Tributavel {
    
    private double limite;
    private double taxaMensal;
    
    public ContaCorrente(int numero, Cliente titular, double limite) {
        super(numero, titular);
        this.limite = limite;
        this.taxaMensal = 15.0; // taxa fixa mensal
    }
    
    @Override
    public boolean sacar(double valor) {
        if (valor > 0 && getSaldo() + limite >= valor) {
            saldo -= valor; // acesso direto pq é protected na Conta
            return true;
        }
        return false;
    }
    
    @Override
    public void atualizar() {
        saldo -= taxaMensal; // cobra taxa todo mês
    }
    
    @Override
    public double calcularTaxa() {
        return taxaMensal;
    }
    
    @Override
    public void exibirDados() {
        super.exibirDados();
        System.out.println("Tipo: Conta Corrente");
        System.out.println("Limite: R$" + limite);
        System.out.println("Taxa Mensal: R$" + taxaMensal);
    }
    
    // Getters e Setters
    public double getLimite() {
        return limite;
    }
    
    public void setLimite(double limite) {
        this.limite = limite;
    }
    
    public double getTaxaMensal() {
        return taxaMensal;
    }
}