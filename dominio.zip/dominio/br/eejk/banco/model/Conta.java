package br.eejk.banco.model;

public abstract class Conta {
    private int numero;
    private Cliente titular;
    protected double saldo;
    
    public Conta(int numero, Cliente titular) {
        this.numero = numero;
        this.titular = titular;
        this.saldo = 0.0;
    }
    
    public boolean sacar(double valor) {
        if (valor > 0 && saldo >= valor) {
            this.saldo -= valor;
            return true;
        }
        return false;
    }
    
    public void depositar(double valor) {
        if (valor > 0) {
            this.saldo += valor;
        }
    }
    
    public boolean transferir(double valor, Conta destino) {
        if (this.sacar(valor)) {
            destino.depositar(valor);
            return true;
        }
        return false;
    }
    
    // Método abstrato - cada tipo de conta implementa sua regra
    public abstract void atualizar();
    
    public void exibirDados() {
        System.out.println("Conta: " + numero);
        System.out.println("Titular: " + titular.getNome());
        System.out.println("Saldo: R$" + saldo);
    }
    
    // Getters
    public int getNumero() {
        return numero;
    }
    
    public Cliente getTitular() {
        return titular;
    }
    
    public double getSaldo() {
        return saldo;
    }
}public class conta {

}
