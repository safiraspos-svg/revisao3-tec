package br.eejk.banco.model;

public class ContaPoupanca extends Conta {
    
    private double taxaRendimento;
    
    public ContaPoupanca(int numero, Cliente titular) {
        super(numero, titular);
        this.taxaRendimento = 0.005; // 0.5% ao mês
    }
    
    @Override
    public void atualizar() {
        double rendimento = getSaldo() * taxaRendimento;
        depositar(rendimento); // rende em cima do saldo atual
    }
    
    @Override
    public void exibirDados() {
        super.exibirDados();
        System.out.println("Tipo: Conta Poupança");
        System.out.println("Rendimento: " + (taxaRendimento * 100) + "% ao mês");
    }
    
    // Getter e Setter
    public double getTaxaRendimento() {
        return taxaRendimento;
    }
    
    public void setTaxaRendimento(double taxaRendimento) {
        if (taxaRendimento > 0) {
            this.taxaRendimento = taxaRendimento;
        }
    }
}