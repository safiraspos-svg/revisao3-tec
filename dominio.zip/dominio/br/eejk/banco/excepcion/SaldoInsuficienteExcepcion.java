package br.eejk.banco.exception;

public class SaldoInsuficienteException extends RuntimeException {
    
    public SaldoInsuficienteException(String mensagem) {
        super(mensagem);
    }
    
    public SaldoInsuficienteException(double saldo, double valorTentativa) {
        super("Saldo insuficiente. Saldo atual: R$" + saldo + ", Tentativa de saque: R$" + valorTentativa);
    }
}