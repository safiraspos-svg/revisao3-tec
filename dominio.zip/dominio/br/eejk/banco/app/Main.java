package br.eejk.banco.app;

import br.eejk.banco.model.*;
import br.eejk.banco.repository.*;

public class Main {
    public static void main(String[] args) {
        
        // 1. Criando repository
        ContaRepository repo = new ContaRepositoryMemoria();
        
        // 2. Criando clientes
        Cliente ana = new Cliente("Ana Silva", "111.222.333-44");
        Cliente bruno = new Cliente("Bruno Costa", "555.666.777-88", "bruno@email.com");
        
        // 3. Criando contas
        ContaCorrente cc = new ContaCorrente(1001, ana, 500.0);
        ContaPoupanca cp = new ContaPoupanca(2001, bruno);
        
        // 4. Salvando no repository
        repo.salvar(cc);
        repo.salvar(cp);
        
        // 5. Testando operações
        System.out.println("=== TESTE INICIAL ===");
        cc.depositar(1000);
        cp.depositar(2000);
        
        cc.exibirDados();
        System.out.println();
        cp.exibirDados();
        
        // 6. Transferência
        System.out.println("\n=== TRANSFERINDO R$300 DA CC PRA CP ===");
        cc.transferir(300, cp);
        
        cc.exibirDados();
        System.out.println();
        cp.exibirDados();
        
        // 7. Atualizando contas
        System.out.println("\n=== ATUALIZANDO CONTAS ===");
        cc.atualizar(); // cobra taxa de 15
        cp.atualizar(); // rende 0.5%
        
        cc.exibirDados();
        System.out.println();
        cp.exibirDados();
        
        // 8. Testando Tributavel
        System.out.println("\n=== TESTANDO INTERFACE TRIBUTAVEL ===");
        Tributavel t = cc;
        System.out.println("Taxa da conta: R$" + t.calcularTaxa());
        
        // 9. Listando tudo do repo
        System.out.println("\n=== TODAS AS CONTAS NO REPOSITORY ===");
        for (Conta c : repo.listarTodas()) {
            System.out.println("Conta " + c.getNumero() + " - Saldo: R$" + c.getSaldo());
        }
        
        // 10. Teste de saque com limite
        System.out.println("\n=== SACANDO R$1000 DA CC COM LIMITE DE 500 ===");
        boolean conseguiu = cc.sacar(1000);
        System.out.println("Saque realizado: " + conseguiu);
        cc.exibirDados();
    }
}